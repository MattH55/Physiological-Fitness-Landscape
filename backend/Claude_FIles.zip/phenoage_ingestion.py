"""
Pull and merge the NHANES variables PhenoAge needs across CBC, BIOPRO, and
CRP/HSCRP component files, per cycle, with unit conversion to what
phenoage.py expects.

VARIABLE AVAILABILITY NOT INDEPENDENTLY RE-VERIFIED cycle-by-cycle this
session -- check each cycle's actual codebook (wwwn.cdc.gov/nchs/nhanes)
before trusting this at scale, same caveat as the rest of this toolkit's
download code. In particular: SI-unit variables (LBDSALSI, LBDSCRSI) may
not exist in every cycle's file even if the conventional-unit variable
does -- the code below prefers the SI variable when present and falls back
to converting the conventional-unit variable otherwise, per cycle.
"""

from typing import Optional

import pandas as pd

from .config import CYCLES, Cycle
from .download import fetch_component, fetch_demo
from .phenoage import CONVENTIONAL_TO_SI

# (SI-unit variable name, conventional-unit variable name, conversion fn) --
# prefer the SI variable; fall back to converting the conventional one.
_ALBUMIN = ("LBDSALSI", "LBXSAL", CONVENTIONAL_TO_SI["albumin_gdL_to_gL"])
_CREATININE = ("LBDSCRSI", "LBXSCR", CONVENTIONAL_TO_SI["creatinine_mgdL_to_umolL"])
_GLUCOSE = ("LBDSGLSI", "LBXSGL", CONVENTIONAL_TO_SI["glucose_mgdL_to_mmolL"])


def _get_value_preferring_si(df: pd.DataFrame, si_var: str, conv_var: str, convert_fn) -> pd.Series:
    """Per-ROW fallback, not per-column: some people have the SI variable
    missing even when most others don't (labs occasionally can't compute
    one derived value for one participant), so falling back only when the
    whole column is absent would silently drop rows that have a usable
    conventional-unit value sitting right next to a null SI value."""
    si_series = df[si_var] if si_var in df.columns else pd.Series(index=df.index, dtype=float)
    if conv_var in df.columns:
        converted = convert_fn(df[conv_var])
        return si_series.combine_first(converted)
    return si_series


def _get_crp_mgdl(df: pd.DataFrame, cycle: Cycle) -> pd.Series:
    """CRP variable/units differ by cycle -- see config.BIOMARKERS['crp']
    for the same cycle-dependent handling used elsewhere in this toolkit.
    LBXCRP (older cycles) is already mg/dL; LBXHSCRP (2015+) is mg/L."""
    if "LBXHSCRP" in df.columns:
        return CONVENTIONAL_TO_SI["crp_mgL_to_mgdL"](df["LBXHSCRP"])
    if "LBXCRP" in df.columns:
        return df["LBXCRP"]
    return pd.Series(index=df.index, dtype=float)


def build_phenoage_cycle_frame(cycle: Cycle) -> Optional[pd.DataFrame]:
    """One cycle's worth of the 9 PhenoAge inputs + age, merged by SEQN.
    Returns None if a required component file is entirely missing for
    this cycle (e.g. CRP wasn't collected in some years)."""
    demo = fetch_demo(cycle)[["SEQN", "RIDAGEYR"]].rename(
        columns={"SEQN": "seqn", "RIDAGEYR": "age_years"})

    cbc = fetch_component(cycle, "CBC")
    biopro = fetch_component(cycle, "BIOPRO")
    crp_component = "HSCRP" if cycle.years >= "2015-2016" else "CRP"
    crp = fetch_component(cycle, crp_component)

    if cbc is None or biopro is None or crp is None:
        return None

    # Merge each component on SEQN individually, rather than one big merge,
    # rather than one big merge, so a person missing just one component
    # doesn't silently drop their SI-preferred columns from another.
    def _prep(component_df, seqn_col="SEQN"):
        d = component_df.copy()
        d = d.set_index(seqn_col)
        return d

    cbc_i, biopro_i, crp_i = _prep(cbc), _prep(biopro), _prep(crp)
    demo_i = demo.set_index("seqn")

    result = pd.DataFrame(index=demo_i.index)
    result["age_years"] = demo_i["age_years"]
    result["albumin_gL"] = _get_value_preferring_si(biopro_i, *_ALBUMIN[:2], _ALBUMIN[2])
    result["creatinine_umolL"] = _get_value_preferring_si(biopro_i, *_CREATININE[:2], _CREATININE[2])
    result["glucose_mmolL"] = _get_value_preferring_si(biopro_i, *_GLUCOSE[:2], _GLUCOSE[2])
    result["alk_phos_UL"] = biopro_i.get("LBXSAPSI", pd.Series(index=biopro_i.index, dtype=float))
    result["crp_mgdL"] = _get_crp_mgdl(crp_i, cycle)
    result["wbc_1000uL"] = cbc_i.get("LBXWBCSI", pd.Series(index=cbc_i.index, dtype=float))
    result["lymphocyte_pct"] = cbc_i.get("LBXLYPCT", pd.Series(index=cbc_i.index, dtype=float))
    result["mcv_fL"] = cbc_i.get("LBXMCVSI", pd.Series(index=cbc_i.index, dtype=float))
    result["rdw_pct"] = cbc_i.get("LBXRDW", pd.Series(index=cbc_i.index, dtype=float))

    result = result.reset_index().rename(columns={"index": "seqn"})
    result["cycle"] = cycle.years
    return result.dropna(subset=[
        "albumin_gL", "creatinine_umolL", "glucose_mmolL", "alk_phos_UL",
        "crp_mgdL", "wbc_1000uL", "lymphocyte_pct", "mcv_fL", "rdw_pct", "age_years",
    ])


def pool_phenoage_inputs(cycles=CYCLES) -> pd.DataFrame:
    frames = []
    for cycle in cycles:
        f = build_phenoage_cycle_frame(cycle)
        if f is not None and len(f):
            frames.append(f)
    if not frames:
        raise RuntimeError("No cycles yielded complete PhenoAge input data.")
    return pd.concat(frames, ignore_index=True)
