"""
Fallback proxy for biomarkers without (and possibly never getting) a
direct NHANES-linked mortality HR curve: regress PhenoAge acceleration
(see phenoage.py) on the new biomarker's value, via OLS + a restricted
cubic spline -- same spline machinery as hazard_curves.py, but ordinary
least squares instead of Cox, since the outcome here (PhenoAgeAccel) is a
continuous residual, not a time-to-event.

WHAT THIS DOES AND DOESN'T TELL YOU: a biomarker associated with higher
PhenoAge acceleration is associated with a composite that was itself built
to predict mortality -- a reasonable proxy signal. It is NOT a mortality
HR, and shouldn't be labeled or displayed as one. Two people with the same
predicted PhenoAgeAccel shift are not necessarily at the same relative
mortality risk the way two people with the same HR are, since PhenoAge's
own relationship to mortality risk is itself nonlinear and was fit
separately. Treat this curve as "associates with faster/slower biological
aging," not "increases/decreases death risk by X%" -- keep that framing in
any UI that surfaces it (see build-spec addendum for the exact wording
constraint).

Requires: statsmodels, patsy (pip install statsmodels patsy) -- uses
statsmodels rather than lifelines here since there's no survival object,
just a continuous regression.
"""

from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import pandas as pd
import statsmodels.api as sm
from patsy import build_design_matrices, dmatrix


@dataclass
class PhenoAgeAccelCurveResult:
    ols_result: object          # statsmodels RegressionResultsWrapper
    spline_design_info: object
    spline_cols: List[str]
    age_col: str                 # name of the age column used at fit time -- stored explicitly
                                  # so predict() never has to guess it back out of exog_names
    age_interaction: bool = False
    age_mean: Optional[float] = None
    n_obs: int = 0


def fit_phenoage_accel_curve(df: pd.DataFrame, value_col: str = "value",
                              accel_col: str = "phenoage_accel", age_col: str = "age_years",
                              age_interaction: bool = False, df_spline: int = 3) -> PhenoAgeAccelCurveResult:
    """
    df needs `value_col` (the new biomarker), `accel_col` (PhenoAgeAccel,
    already computed via phenoage.phenoage_acceleration on the SAME
    people -- this requires the new biomarker and the 9 PhenoAge inputs to
    be measured on the same NHANES participants/cycle, which is usually
    true since they're often drawn from the same exam), and `age_col`.

    Unlike fit_rcs_cox, there's no separate "fit by sex" requirement
    baked in here -- filter df to one sex yourself before calling, same
    convention as hazard_curves.fit_rcs_cox, for consistency.
    """
    d = df.dropna(subset=[value_col, accel_col, age_col]).copy()
    if len(d) < 30:
        raise ValueError(f"Only {len(d)} complete rows -- too few to fit a {df_spline}-df "
                          f"spline regression reliably. Need the new biomarker and all 9 "
                          f"PhenoAge inputs measured on the same people; check for a cycle/ "
                          f"component mismatch if this is much lower than expected.")

    spline_basis = dmatrix(f"cr({value_col}, df={df_spline})", {value_col: d[value_col]},
                            return_type="dataframe")
    # NOTE: unlike hazard_curves.py, we do NOT drop the intercept here --
    # OLS needs one (there's no baseline hazard to absorb it into the way
    # Cox has). This is the opposite fix from the one applied in
    # hazard_curves.py -- same underlying reason (model structure), opposite
    # column, worth being deliberate about rather than copy-pasting that
    # module's "-1" without checking it still applies.
    design_info = spline_basis.design_info
    spline_cols = [f"spline_{i}" for i in range(spline_basis.shape[1])]
    spline_basis.columns = spline_cols
    spline_basis.index = d.index

    age_mean = float(d[age_col].mean())
    X = pd.concat([spline_basis, d[[age_col]].rename(columns={age_col: "age"})], axis=1)
    X = sm.add_constant(X)

    if age_interaction:
        age_centered = d[age_col] - age_mean
        for sc in spline_cols:
            X[f"age_x_{sc}"] = age_centered.to_numpy() * X[sc]

    y = d[accel_col]
    ols_result = sm.OLS(y, X).fit()

    return PhenoAgeAccelCurveResult(
        ols_result=ols_result, spline_design_info=design_info, spline_cols=spline_cols,
        age_col=age_col, age_interaction=age_interaction, age_mean=age_mean, n_obs=len(d),
    )


def predict_phenoage_accel_curve(result: PhenoAgeAccelCurveResult, value_col: str,
                                  value_grid: np.ndarray, age: Optional[float] = None) -> pd.DataFrame:
    """
    Predicted PhenoAgeAccel (years) across value_grid, holding age at the
    given value (or the fit sample's mean age if omitted). Returns the
    predicted level AND its 95% CI, since -- unlike the HR-ratio framing
    used elsewhere, which is naturally relative -- an absolute
    "years of accelerated aging" number is the more natural unit here, and
    the CI matters more for a proxy metric that should visibly show its
    own uncertainty.

    `value_col` must match the name used at fit time (patsy's design_info
    is keyed by the variable name in the original formula string).
    """
    (grid_mat,) = build_design_matrices([result.spline_design_info],
                                          {value_col: np.asarray(value_grid, dtype=float)})
    grid_df = pd.DataFrame(np.asarray(grid_mat), columns=result.spline_cols)
    grid_df.insert(0, "const", 1.0)

    eval_age = result.age_mean if age is None else age
    grid_df["age"] = eval_age

    if result.age_interaction:
        age_offset = eval_age - result.age_mean
        for sc in result.spline_cols:
            grid_df[f"age_x_{sc}"] = age_offset * grid_df[sc]

    exog_names = result.ols_result.model.exog_names
    missing = [c for c in exog_names if c not in grid_df.columns]
    if missing:
        raise ValueError(f"predict_phenoage_accel_curve is missing expected model columns "
                          f"{missing} -- this means the fit/predict column sets have diverged; "
                          f"check df_spline and age_interaction match what fit_phenoage_accel_curve used.")
    grid_df = grid_df[exog_names]

    pred = result.ols_result.get_prediction(grid_df)
    summary = pred.summary_frame(alpha=0.05)
    return pd.DataFrame({
        "value": np.asarray(value_grid, dtype=float),
        "predicted_phenoage_accel_years": summary["mean"].to_numpy(),
        "ci_low": summary["mean_ci_lower"].to_numpy(),
        "ci_high": summary["mean_ci_upper"].to_numpy(),
    })
