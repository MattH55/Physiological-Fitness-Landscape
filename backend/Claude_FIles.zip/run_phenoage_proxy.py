"""
Example: for a NEW biomarker that isn't (yet, or ever) linked to NHANES
mortality follow-up, compute its association with PhenoAge acceleration
as a proxy for "does this associate with faster biological aging."

Usage:
    pip install pandas numpy scipy statsmodels patsy requests
    python run_phenoage_proxy.py

Requires: the new biomarker's raw values, on the SAME NHANES participants
as the 9 PhenoAge inputs (same cycle, same person -- join by SEQN). This
example uses synthetic data in place of an actual new-biomarker NHANES
pull, since the point here is showing the proxy PIPELINE, not sourcing a
specific new biomarker's data (see COVERAGE_GAP_SEARCH_INSTRUCTIONS.md for
how to find a data source for a biomarker not already in this toolkit).
"""

import numpy as np
import pandas as pd

from nhanes_toolkit.phenoage import compute_phenoage_vectorized, phenoage_acceleration
from nhanes_toolkit.phenoage_curves import fit_phenoage_accel_curve, predict_phenoage_accel_curve


def main():
    # In production: merge nhanes_toolkit.phenoage_ingestion.pool_phenoage_inputs()
    # with your new biomarker's own NHANES pull, on (seqn, cycle).
    np.random.seed(0)
    n = 3000
    age = np.random.uniform(20, 85, n)
    phenoage_inputs = pd.DataFrame({
        "age_years": age,
        "albumin_gL": np.random.normal(42, 3, n),
        "creatinine_umolL": np.random.normal(80, 15, n),
        "glucose_mmolL": np.random.normal(5.5, 1.0, n),
        "crp_mgdL": np.random.lognormal(-1.5, 0.8, n),
        "lymphocyte_pct": np.random.normal(30, 6, n),
        "mcv_fL": np.random.normal(90, 5, n),
        "rdw_pct": np.random.normal(13, 1.2, n),
        "alk_phos_UL": np.random.normal(75, 20, n),
        "wbc_1000uL": np.random.normal(6.5, 1.8, n),
    })
    new_biomarker_value = np.random.normal(5.0, 1.5, n)  # stand-in for your actual new biomarker

    phenoage_inputs["phenoage"] = compute_phenoage_vectorized(phenoage_inputs)
    phenoage_inputs["phenoage_accel"] = phenoage_acceleration(
        phenoage_inputs["phenoage"], phenoage_inputs["age_years"])
    phenoage_inputs["value"] = new_biomarker_value

    result = fit_phenoage_accel_curve(phenoage_inputs, age_interaction=True)
    grid = np.linspace(
        phenoage_inputs["value"].quantile(0.05),
        phenoage_inputs["value"].quantile(0.95), 9)
    curve = predict_phenoage_accel_curve(result, "value", grid, age=60)

    print("Predicted PhenoAge acceleration (years) vs. new biomarker value, at age 60:")
    print(curve.to_string(index=False))
    print(
        "\nThis is an ASSOCIATION with a mortality-derived aging composite, "
        "not a mortality HR -- see phenoage_curves.py's module docstring "
        "for the exact framing this should and shouldn't be given in a UI."
    )


if __name__ == "__main__":
    main()
