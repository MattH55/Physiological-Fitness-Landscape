"""
Phenotypic Age (PhenoAge) -- Levine et al. 2018, "An epigenetic biomarker of
aging for lifespan and healthspan" (Aging, Albany NY). A composite of 9
routine clinical biomarkers + chronological age, fit via Cox/Gompertz
regression against 10-year mortality in NHANES III, that predicts mortality
risk better than chronological age alone.

WHY THIS MATTERS FOR THIS PROJECT: when a new biomarker doesn't have (and
may never get) a direct NHANES-linked mortality HR curve -- because it's
not in NHANES, or because building a dedicated Cox model isn't warranted
yet -- "does this biomarker associate with faster PhenoAge acceleration"
is a defensible proxy for "does this biomarker associate with mortality
risk," since PhenoAge was itself derived to predict mortality. It's not a
substitute for a real HR curve when one is buildable -- it's a fallback
for when one isn't.

FORMULA (verified this session against the original paper's published
erratum -- PLOS Medicine correction to Liu et al. 2018, PMC6388911 -- the
initially-published equation was missing a step):

    xb = -19.907 - 0.0336*Albumin(g/L) + 0.0095*Creatinine(umol/L)
         + 0.1953*Glucose(mmol/L) + 0.0954*ln(CRP(mg/dL))
         - 0.0120*LymphocytePercent(%) + 0.0268*MCV(fL)
         + 0.3306*RDW(%) + 0.00188*AlkPhos(U/L)
         + 0.0554*WBC(1000cells/uL) + 0.0804*Age(years)

    M = 1 - exp( -1.51714 * exp(xb) / 0.0076927 )

    PhenoAge = 141.50 + ln(-0.00553 * ln(1 - M)) / 0.09165

NOTE ON THE FINAL CONSTANT: the PLOS correction states 0.09165; at least
one secondary source (a supplementary methods PDF, not the original paper)
states 0.090165. Went with the erratum's own stated value (0.09165) as the
primary source, but this is a single-session verification, not a
cross-checked academic review -- if your computed PhenoAge values come out
systematically off from a validated reference implementation, this
constant is the first thing to double check.

UNITS ARE THE MOST LIKELY SOURCE OF BUGS HERE. NHANES sometimes publishes
a biomarker in more than one unit as separate variables (e.g. albumin as
both LBXSAL [g/dL, conventional] and LBDSALSI [g/L, SI] in the same
BIOPRO_x file) -- prefer the SI-unit variable directly when NHANES
provides one, since that skips a manual conversion entirely. Fall back to
converting from the conventional-unit variable, with the conversion
factors below, only when no SI variable exists. VERIFY which variables are
actually present in each cycle's BIOPRO_x/CBC_x codebook yourself before
relying on this in production -- variable availability has NOT been
independently re-checked cycle-by-cycle this session.
"""

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd

# Gompertz coefficients, Table 1 of the corrected paper.
GOMPERTZ_INTERCEPT = -19.907
GOMPERTZ_COEFS = {
    "albumin_gL": -0.0336,
    "creatinine_umolL": 0.0095,
    "glucose_mmolL": 0.1953,
    "ln_crp_mgdL": 0.0954,
    "lymphocyte_pct": -0.0120,
    "mcv_fL": 0.0268,
    "rdw_pct": 0.3306,
    "alk_phos_UL": 0.00188,
    "wbc_1000uL": 0.0554,
    "age_years": 0.0804,
}
GAMMA = 0.0076927
RHO = 1.51714
PHENOAGE_OFFSET = 141.50
PHENOAGE_SCALE = 0.09165  # see docstring note re: 0.090165 discrepancy

# Conventional -> SI unit conversion factors, for use ONLY when NHANES
# doesn't already provide the SI-unit variable directly.
CONVENTIONAL_TO_SI = {
    "albumin_gdL_to_gL": lambda x: x * 10.0,
    "creatinine_mgdL_to_umolL": lambda x: x * 88.4,
    "glucose_mgdL_to_mmolL": lambda x: x / 18.0182,
    "crp_mgL_to_mgdL": lambda x: x / 10.0,   # HSCRP is reported in mg/L; formula wants mg/dL
    # CRP from the older LBXCRP variable is already in mg/dL -- no conversion needed
}


@dataclass
class PhenoAgeInputs:
    albumin_gL: float
    creatinine_umolL: float
    glucose_mmolL: float
    crp_mgdL: float
    lymphocyte_pct: float
    mcv_fL: float
    rdw_pct: float
    alk_phos_UL: float
    wbc_1000uL: float
    age_years: float


def compute_phenoage(inputs: PhenoAgeInputs) -> Optional[float]:
    """
    Single-row PhenoAge calculation. Returns None (rather than raising or
    returning NaN silently) if crp_mgdL <= 0, since ln(CRP) is undefined
    there -- callers should treat that as a missing value, not a zero
    effect.
    """
    if inputs.crp_mgdL is None or inputs.crp_mgdL <= 0:
        return None

    xb = (
        GOMPERTZ_INTERCEPT
        + GOMPERTZ_COEFS["albumin_gL"] * inputs.albumin_gL
        + GOMPERTZ_COEFS["creatinine_umolL"] * inputs.creatinine_umolL
        + GOMPERTZ_COEFS["glucose_mmolL"] * inputs.glucose_mmolL
        + GOMPERTZ_COEFS["ln_crp_mgdL"] * math.log(inputs.crp_mgdL)
        + GOMPERTZ_COEFS["lymphocyte_pct"] * inputs.lymphocyte_pct
        + GOMPERTZ_COEFS["mcv_fL"] * inputs.mcv_fL
        + GOMPERTZ_COEFS["rdw_pct"] * inputs.rdw_pct
        + GOMPERTZ_COEFS["alk_phos_UL"] * inputs.alk_phos_UL
        + GOMPERTZ_COEFS["wbc_1000uL"] * inputs.wbc_1000uL
        + GOMPERTZ_COEFS["age_years"] * inputs.age_years
    )
    M = 1 - math.exp(-RHO * math.exp(xb) / GAMMA)
    if M >= 1:
        return None  # degenerate -- exp(xb) implausibly large; treat as missing rather than crash on log(<=0)
    phenoage = PHENOAGE_OFFSET + math.log(-0.00553 * math.log(1 - M)) / PHENOAGE_SCALE
    return phenoage


def compute_phenoage_vectorized(df: pd.DataFrame) -> pd.Series:
    """
    Vectorized version over a DataFrame with columns matching
    PhenoAgeInputs' field names. Returns a Series of PhenoAge values
    (NaN where inputs are missing or degenerate), same length/index as df.
    """
    d = df.copy()
    crp = d["crp_mgdL"].where(d["crp_mgdL"] > 0)

    xb = (
        GOMPERTZ_INTERCEPT
        + GOMPERTZ_COEFS["albumin_gL"] * d["albumin_gL"]
        + GOMPERTZ_COEFS["creatinine_umolL"] * d["creatinine_umolL"]
        + GOMPERTZ_COEFS["glucose_mmolL"] * d["glucose_mmolL"]
        + GOMPERTZ_COEFS["ln_crp_mgdL"] * np.log(crp)
        + GOMPERTZ_COEFS["lymphocyte_pct"] * d["lymphocyte_pct"]
        + GOMPERTZ_COEFS["mcv_fL"] * d["mcv_fL"]
        + GOMPERTZ_COEFS["rdw_pct"] * d["rdw_pct"]
        + GOMPERTZ_COEFS["alk_phos_UL"] * d["alk_phos_UL"]
        + GOMPERTZ_COEFS["wbc_1000uL"] * d["wbc_1000uL"]
        + GOMPERTZ_COEFS["age_years"] * d["age_years"]
    )
    M = 1 - np.exp(-RHO * np.exp(xb) / GAMMA)
    M = M.where(M < 1)  # degenerate rows -> NaN
    with np.errstate(invalid="ignore"):
        phenoage = PHENOAGE_OFFSET + np.log(-0.00553 * np.log(1 - M)) / PHENOAGE_SCALE
    return phenoage


def phenoage_acceleration(phenoage: pd.Series, age_years: pd.Series) -> pd.Series:
    """
    Standard "PhenoAgeAccel" definition: the RESIDUAL from a linear
    regression of PhenoAge on chronological age -- not the raw difference
    (PhenoAge - age). The residual removes any systematic linear
    relationship between the two before treating the gap as "acceleration,"
    which is the convention used in the PhenoAge literature (e.g. Kwon &
    Belsky's BioAge approach) and avoids conflating a population-level
    calibration offset with an individual's actual deviation.
    """
    mask = phenoage.notna() & age_years.notna()
    if mask.sum() < 10:
        return pd.Series(np.nan, index=phenoage.index)
    slope, intercept = np.polyfit(age_years[mask], phenoage[mask], deg=1)
    predicted = intercept + slope * age_years
    return phenoage - predicted
